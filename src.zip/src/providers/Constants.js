"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GOODLIST_URL = 'http://rapapi.org/mockjsdata/18396/api/discove/goodlist';
exports.GOODLIST_head_URL = 'http://img.lapin365.com/productpictures';
