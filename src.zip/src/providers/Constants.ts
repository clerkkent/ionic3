export const GOODLIST_URL = 'http://rapapi.org/mockjsdata/18396/api/discove/goodlist';
export const GOODLIST_head_URL = 'http://img.lapin365.com/productpictures';



